.. Summenberechnung documentation master file, created by
   sphinx-quickstart on Sun Nov 13 19:59:07 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Summenberechnung's documentation!
============================================

Bibliographic fields:
============================================
   :Author: Michael Jindra
   :Organisation: Technologisches Gewerbemuseum
   :date: 2016-11-08
   :status: "finish"
   :revision: 1.0
   :version: 1.0

Contents:

.. toctree::
   :maxdepth: 2

   Summenberechnung

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`