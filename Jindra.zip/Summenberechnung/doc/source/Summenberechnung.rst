Summenberechnung Modul
-----------------------

.. automodule:: Summenberechnung
.. autoclass:: Summenberechnung
    :members:
    :private-members:
    :undoc-members:
    :special-members: __init__
    :show-inheritance:
